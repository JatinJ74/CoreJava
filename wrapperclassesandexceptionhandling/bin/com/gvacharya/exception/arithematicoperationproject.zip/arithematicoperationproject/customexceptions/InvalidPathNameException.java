package com.gvacharya.exception.arithematicoperationproject.customexceptions;

public class InvalidPathNameException extends Exception{

	public InvalidPathNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidPathNameException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidPathNameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidPathNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidPathNameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
